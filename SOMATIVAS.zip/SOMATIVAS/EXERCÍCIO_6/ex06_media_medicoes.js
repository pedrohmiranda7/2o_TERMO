// Durante um teste de processo, são realizadas cinco medições. Crie um programa que leia as cinco medições e calcule a média.

const entrada = require('readline-sync');

let somaMedicoes = 0;

for (let i = 0; i <= 4; i++) {
    const medicao = entrada.questionFloat(`Digite a medicao ${i}: \n`);
    somaMedicoes = somaMedicoes + medicao;
}

const media = somaMedicoes / 5;
console.log(`Soma das medições: ${somaMedicoes}`);
console.log(`Media das medicoes: ${media}`);