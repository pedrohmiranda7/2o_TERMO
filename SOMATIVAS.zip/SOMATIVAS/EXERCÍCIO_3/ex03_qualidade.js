// Uma peça será aprovada no controle de qualidade quando seu peso estiver entre 95 g e 105 g, inclusive. Crie um programa que leia o peso e informe o resultado da inspeção.

const entrada = require('readline-sync');

const pesoPeca = entrada.questionFloat("Digite o peso da peca: \n");

if (pesoPeca >= 95 && pesoPeca <= 105) {
    console.log("PECA APROVADA!")
} else {
    console.log("PECA REPROVADA!")
};

console.log(`O peso da peca é ${pesoPeca.toFixed(2)}g.`)