// Uma linha de produção fabrica uma determinada quantidade de peças por hora. Crie um programa que calcule quantas peças serão produzidas em um turno.

const pecasHora = 120;
const horasTurno = 8;

const pecasProduzidas = pecasHora * horasTurno;

console.log(`Em um turno de ${horasTurno} horas, serão produzidas ${pecasProduzidas} peças!`);