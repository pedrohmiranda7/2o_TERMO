// Crie um programa para calcular o custo de uma compra de matéria-prima.

const entrada = require('readline-sync');

const nomeMaterial = entrada.question("Digite o nome do material: \n");

const quantidade = entrada.questionInt("Digite a quantidade que foi comprada: \n");

const precoUnitario = entrada.questionFloat("Digite o preco unitario do material: \n")

const valorTotal = quantidade * precoUnitario

console.log("=== CALCULO DA MATERIA PRIMA ===");
console.log(`Material: ${nomeMaterial} - Valor total da compra: ${valorTotal.toFixed(2)}.`);