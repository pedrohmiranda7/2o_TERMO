// Uma máquina produz uma quantidade fixa de peças a cada ciclo. Crie um programa que mostre a produção acumulada do ciclo 1 até o ciclo 10.

const entrada = require ('readline-sync');

const pecasPorCiclo = entrada.questionFloat("Digite a quantidade de pecas produzidas por ciclo: \n");

let producaoAcumulada = 0;

for (let ciclo = 0; ciclo <= 9; ciclo++) {
 producaoAcumulada = producaoAcumulada + pecasPorCiclo;
    console.log(`Ciclo ${ciclo}: ${producaoAcumulada} peças`);
}   