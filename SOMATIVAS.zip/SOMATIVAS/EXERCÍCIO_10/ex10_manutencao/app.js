const entrada = require('readline-sync');
const calculo = require('./funcoesManutencao');

const nome = entrada.question("Digite o nome da máquina: \n")
const pecas = entrada.questionFloat('Digite o valor das pecas: \n');
const horas = entrada.questionFloat('Digite a quantidade de horas trabalhadas: \n');
const meses = entrada.questionInt('Digite a quantidade de meses desde a ultima manutencao: \n');

console.log("=== RELATORIO FINAL ===")

console.log(`Nome da maquina: ${nome} \n`)
console.log(`Mão de Obra: ${calculo.calcularMaoDeObra(horas)}`)
console.log(`Quantidade de peças: ${pecas}`)
console.log(`Status de Garantia: ${calculo.verificarGarantia(meses)} \n`);
console.log(`Total: R$ ${calculo.calcularTotal(pecas, horas).toFixed(2)}\n`);