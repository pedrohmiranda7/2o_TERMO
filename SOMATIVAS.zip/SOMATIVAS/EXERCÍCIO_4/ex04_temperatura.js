// Crie um programa que leia a temperatura de uma máquina e classifique sua situação.

const entrada = require('readline-sync');

const temperatura = entrada.questionFloat("Digite a temperatura da maquina em graus (°): \n");

if (temperatura <= 60) {
    console.log("SITUACAO NORMAL");
} else if (temperatura <= 80) {
    console.log("SITUACAO ATENCAO");
} else {
    console.log("SITUACAO CRITICA");
}