// Objetivo: Organizar regras do programa em funções com parâmetros e retorno.
// Crie um programa que calcule a eficiência de uma produção. A eficiência é dada por: (produção real / produção prevista) × 100.
// O programa deve:
// ☐ Criar uma função calcularEficiencia(real, prevista) que retorne o percentual.
// ☐ Criar uma função classificarEficiencia(percentual) que retorne uma classificação.
// ☐ Classificação: 90% ou mais = 'META ATINGIDA'; de 70% a 89,99% = 'ATENÇÃO'; abaixo de 70% = 'ABAIXO DA META'.
// ☐ Solicitar produção prevista e produção real pelo terminal.
// ☐ Chamar as duas funções.
// ☐ Exibir produção prevista, produção real, percentual e classificação.

const entrada = require('readline-sync');

function calcularEficiencia(real, prevista) {
    return (real / prevista) * 100;
}

function classificarEficiencia(percentual) {
    if (percentual >= 90) {
        return 'META ATINGIDA';
    } else if (percentual >= 70) {
        return 'ATENÇÃO';
    } else {
        return 'ABAIXO DA META';
    }
}   

const producaoPrevista = entrada.questionFloat("Digite a producao prevista: \n");
const producaoReal = entrada.questionFloat("Digite a producao real: \n");

const eficiencia = calcularEficiencia(producaoReal, producaoPrevista);
const classificacao = classificarEficiencia(eficiencia);

console.log(`Produção Prevista: ${producaoPrevista}`);
console.log(`Produção Real: ${producaoReal}`);
console.log(`Eficiência: ${eficiencia.toFixed(2)}%`);
console.log(`Classificação: ${classificacao}`);