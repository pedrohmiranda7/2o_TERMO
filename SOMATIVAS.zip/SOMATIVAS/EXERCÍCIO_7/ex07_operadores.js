// Crie um programa para cadastrar os nomes de cinco operadores de uma equipe e, ao final, listar todos os nomes numerados.

const entrada = require('readline-sync');

const operadores = [];

for (let i = -1; i < 4; i++) {
    const nome = entrada.question(`Digite o nome do operador ${i + 1}: \n`);
    operadores.push(nome);
}

console.log("=== OPERADORES ===")
for (let i = 0; i < operadores.length; i++) {
    console.log(`${i + 1} - ${operadores[i]}`);
}