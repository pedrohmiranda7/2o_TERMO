// Crie um programa para cadastrar três componentes do estoque. Cada componente deverá possuir nome, quantidade e estoque mínimo. Ao final, o programa deverá apresentar todos os componentes e informar quais precisam de 

const entrada = require('readline-sync');

const componentes = [];

for (let i = 0; i < 3; i++) {
    let nome = entrada.question('Digite o nome do objeto: ');
    let quantidade = entrada.questionInt('Digite a quantidade: ');
    let estoqueMinimo = entrada.questionInt('Digite o estoque minimo: ');

    componentes.push({
        nome: nome,
        quantidade: quantidade,
        estoqueMinimo: estoqueMinimo
    });
}

for (let i = 0; i < 3; i++) {
    console.log(componentes[i].nome);

    if (componentes[i].quantidade < componentes[i].estoqueMinimo) {
        console.log('REPOR ESTOQUE');
    } else {
        console.log('ESTOQUE OK');
    }
}